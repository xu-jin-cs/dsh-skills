# Kimi Code 多智能体工作流体系 · 体验合集（15 个技能）

面向 AI 编程智能体的轻量入门包，包含 7 个框架技能、4 个规则包和 4 个最常用门禁技能。

## 包含技能

### 框架技能（7）

- `gate-switch` — 通用门禁引擎
- `parallel-dispatch` — 并行调度与子分身机制
- `dual-gates` — 声明闸 + 查询闸
- `plan-select` — 方案择优引擎
- `bug-fix-strategy` — Bug 最短路径修复策略
- `scope-boundary-gate` — 范围边界门禁
- `idea-forge` — 设想锻造炉

### 规则文档包（4）

- `workflow-governance` — 工作流治理规则
- `roles-and-standards` — 角色职责与工程标准
- `test-quality-system` — 测试质量体系
- `governance-archive` — 治理规则与归档史

### 最常用门禁（4）

- `danger_cmd_gate` — 危险命令事前拦截
- `problem_gate` — 问题根治决策树
- `zero_residual` — 零残留验证
- `no_abs_path` — 绝对路径硬编码零容忍

## 安装

```bash
# 全套安装
cp -R skills/* ~/.agents/skills/

# 或单个技能安装
cp -R skills/<技能名> ~/.agents/skills/
```

## 运行前提

- Kimi Code CLI（或其他支持 SKILL.md 的 Agent 运行时）
- Python 3（纯 stdlib，`jieba` 为可选依赖）

## 上传必看：Git 发布前兼容性检查

> 以后任何项目上传到 Git 前，必须先按此清单检查；不通过禁止上传。

### 1. 路径必须可移植

- [ ] 禁止出现本机绝对路径：`/Users/<用户名>`、`C:\Users\...`、`/home/...`
- [ ] 路径统一使用相对路径 `./data/...`、`$HOME`、`Path.home()` 或环境变量
- [ ] 代码、文档、配置中不得出现私人目录名

### 2. 凭据必须清零

- [ ] 不得出现真实 `password` / `secret` / `token` / `api_key` / 私钥
- [ ] 已泄露的账号密码必须删除
- [ ] 新增 `.env.example`，真实配置通过环境变量注入

### 3. 私有依赖必须剥离

- [ ] 不得 import 外部私有项目模块，例如 `backend.*`、`etl.common.*`
- [ ] 不得出现内部私有项目名：`agent-harness`、`retro-skills-registry`、`Xj-rules`、个人名等
- [ ] 仓库必须能独立 `clone` 后按 README 安装并运行

### 4. 无关文件必须忽略

- [ ] `data/`、`__pycache__/`、`*.pyc`、`.DS_Store`、`node_modules/`、`*.tgz`、`*.zip` 不入库
- [ ] 数据库文件、模型权重、大体积临时文件不入库

### 5. 上传前必须执行校验

```bash
grep -RIn --exclude-dir=.git --exclude-dir=data -E '/Users/|C:\\Users|/home/' .
grep -RIn --exclude-dir=.git -iE 'password|secret|token|api[_-]?key' .
```

- [ ] Python 语法检查通过
- [ ] YAML / JSON 解析通过
- [ ] 在全新目录 `git clone` 后，按 README 跑通最小示例

## 许可证

仅限购买者本人项目使用，禁止二次分发/转售。
